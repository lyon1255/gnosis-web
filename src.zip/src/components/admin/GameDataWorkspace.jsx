import React, { useState } from 'react';
import { Box, History, ScrollText, Sparkles, Wand2, Users } from 'lucide-react';
import QuestEditorPage from './QuestEditorPage';

const tabs = [
  { key: 'items', label: 'Items', icon: Box },
  { key: 'auras', label: 'Auras', icon: Sparkles },
  { key: 'entities', label: 'Entities', icon: Users },
  { key: 'quests', label: 'Quests', icon: ScrollText },
  { key: 'spells', label: 'Spells', icon: Wand2 },
  { key: 'versions', label: 'Versions', icon: History },
];

function Placeholder({ label }) {
  return (
    <div className="bg-[#162031] rounded-2xl border border-white/5 p-10 text-center text-white/35">
      <p className="text-[10px] font-black uppercase tracking-[0.24em] text-[#2EF2C4] mb-4">Next Step</p>
      <h3 className="text-2xl font-montserrat font-black text-white mb-3">{label}</h3>
      <p>This module shell is ready. The Quests editor is the first fully mirrored Unity-to-web surface.</p>
    </div>
  );
}

export default function GameDataWorkspace() {
  const [tab, setTab] = useState('quests');

  return (
    <div className="space-y-6">
      <div className="bg-[#162031] rounded-2xl border border-white/5 p-3 flex flex-wrap gap-2">
        {tabs.map((entry) => {
          const Icon = entry.icon;
          const active = entry.key === tab;
          return (
            <button key={entry.key} onClick={() => setTab(entry.key)} className={`px-4 py-3 rounded-xl text-sm font-black flex items-center gap-2 transition-all ${active ? 'bg-[#7A3CFF] text-white shadow-xl shadow-[#7A3CFF]/20' : 'bg-transparent text-white/45 hover:bg-white/5 hover:text-white'}`}>
              <Icon size={16} /> {entry.label}
            </button>
          );
        })}
      </div>

      {tab === 'quests' ? <QuestEditorPage /> : <Placeholder label={tabs.find((x) => x.key === tab)?.label || 'Module'} />}
    </div>
  );
}
