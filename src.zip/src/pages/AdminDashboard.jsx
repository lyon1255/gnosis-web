import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, FileText, Activity, Database, LogOut, 
  Users as UsersIcon, Bug, CheckCircle, ChevronRight, User, 
  Trash2, ShieldAlert, Globe, Bell, Server, ShieldCheck, AlertTriangle, Package
} from 'lucide-react';
import { AnimatedSection } from '../components/Shared';
import { signOut } from 'firebase/auth';
import { auth, db } from '../firebase';
import { doc, deleteDoc, collection, onSnapshot, query, updateDoc, setDoc } from 'firebase/firestore';
import { useNavigate, Link } from 'react-router-dom';

// Importáljuk az új Item Editort!
import ItemEditor from './ItemEditor';

export default function AdminDashboard({ patchNotes, stats, userRole }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [bugReports, setBugReports] = useState([]);
  const [usersList, setUsersList] = useState([]);
  const [systemSettings, setSettings] = useState({ maintenance: false, announcement: '', serverStatus: 'online' });
  const [bugFilter, setBugFilter] = useState('new');
  const navigate = useNavigate();

  // 1. ADATOK BETÖLTÉSE
  useEffect(() => {
    // Bugok figyelése - Hibakezeléssel
    const unsubBugs = onSnapshot(query(collection(db, 'bugReports')), 
      (snap) => {
        const reports = [];
        snap.forEach(doc => reports.push({ id: doc.id, ...doc.data() }));
        
        const filtered = reports.filter(bug => {
          if (userRole === 'owner') return true;
          if (userRole === 'developer') return ['In-Game', 'Website', 'Other'].includes(bug.category);
          if (userRole === 'moderator') return bug.category === 'Discord';
          return false;
        });
        setBugReports(filtered.sort((a, b) => b.timestamp - a.timestamp));
      },
      (error) => console.error("Bug loading error (check rules):", error)
    );

    // Beállítások figyelése
    const unsubSettings = onSnapshot(doc(db, 'settings', 'global'), (doc) => {
      if (doc.exists()) setSettings(doc.data());
    });

    // Felhasználók (csak ownernek)
    let unsubUsers;
    if (userRole === 'owner') {
      unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
        const arr = [];
        snap.forEach(d => arr.push({uid: d.id, ...d.data()}));
        setUsersList(arr);
      });
    }

    return () => { unsubBugs(); unsubSettings(); if (unsubUsers) unsubUsers(); };
  }, [userRole]);

  const handleLogout = async () => { await signOut(auth); navigate('/'); };
  
  // Javított mentés: minden módosításnál azonnal küldi az adatbázisba
  const updateGlobalSettings = async (newData) => {
    try {
      const settingsRef = doc(db, 'settings', 'global');
      await setDoc(settingsRef, { ...systemSettings, ...newData }, { merge: true });
    } catch (e) {
      console.error("Settings update failed:", e);
    }
  };

  const updateBugStatus = async (id, newStatus) => {
    await updateDoc(doc(db, 'bugReports', id), { status: newStatus });
  };

  const updateUserRole = async (uid, newRole) => {
    if (window.confirm(`Promote user to ${newRole.toUpperCase()}?`)) {
      await updateDoc(doc(db, 'users', uid), { role: newRole });
    }
  };

  const displayedBugs = bugReports.filter(b => bugFilter === 'all' ? true : b.status === bugFilter);

  return (
    <main className="pt-32 lg:pt-40 pb-20 px-6 md:px-12 lg:px-20 min-h-screen bg-[#0E1624]">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-8">
        
        {/* SIDEBAR */}
        <aside className="w-full lg:w-72 space-y-2">
          <div className="p-6 mb-6 bg-[#162031] border border-white/5 rounded-2xl relative overflow-hidden">
             <div className={`absolute top-0 left-0 w-1.5 h-full ${userRole==='owner'?'bg-red-500':'bg-[#2EF2C4]'}`}></div>
             <h2 className="font-montserrat font-black text-xl text-white tracking-tighter">GNOSIS COMMAND</h2>
             <p className="text-[10px] text-[#2EF2C4] font-black uppercase tracking-widest mt-1">Level: {userRole}</p>
          </div>

          <nav className="space-y-1">
            <button onClick={() => setActiveTab('overview')} className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl font-bold transition-all ${activeTab==='overview'?'bg-[#7A3CFF] text-white shadow-xl':'text-white/40 hover:bg-white/5'}`}>
              <LayoutDashboard size={20}/> Overview
            </button>
            
            {userRole === 'owner' && (
              <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl font-bold transition-all ${activeTab==='settings'?'bg-[#7A3CFF] text-white shadow-xl':'text-white/40 hover:bg-white/5'}`}>
                <Globe size={20}/> Global Control
              </button>
            )}

            {/* ÚJ: ITEM DATABASE GOMB (Csak Fejlesztőknek és Ownereknek) */}
            {['owner', 'developer'].includes(userRole) && (
              <button onClick={() => setActiveTab('items')} className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl font-bold transition-all ${activeTab==='items'?'bg-[#7A3CFF] text-white shadow-xl':'text-white/40 hover:bg-white/5'}`}>
                <Package size={20}/> Item Database
              </button>
            )}

            {['owner', 'developer'].includes(userRole) && (
              <button onClick={() => setActiveTab('patches')} className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl font-bold transition-all ${activeTab==='patches'?'bg-[#7A3CFF] text-white shadow-xl':'text-white/40 hover:bg-white/5'}`}>
                <FileText size={20}/> Patch Notes
              </button>
            )}

            <button onClick={() => setActiveTab('bugs')} className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl font-bold transition-all ${activeTab==='bugs'?'bg-[#7A3CFF] text-white shadow-xl':'text-white/40 hover:bg-white/5'}`}>
              <Bug size={20}/> Reports ({bugReports.filter(b=>b.status==='new').length})
            </button>
            
            {userRole === 'owner' && (
              <button onClick={() => setActiveTab('users')} className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl font-bold transition-all ${activeTab==='users'?'bg-[#7A3CFF] text-white shadow-xl':'text-white/40 hover:bg-white/5'}`}>
                <ShieldAlert size={20}/> Personnel
              </button>
            )}
          </nav>
        </aside>

        {/* CONTENT AREA */}
        <div className="flex-grow">
          
          {/* OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <AnimatedSection className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-[#162031] p-8 rounded-2xl border border-white/5">
                  <Activity className="text-[#2EF2C4] mb-4" size={32}/>
                  <p className="text-white/30 text-[10px] font-black uppercase tracking-widest">Total Traffic</p>
                  <h3 className="text-4xl font-montserrat font-black text-white">{stats.totalViews?.toLocaleString()}</h3>
                </div>
                <div className="bg-[#162031] p-8 rounded-2xl border border-white/5">
                  <Server className={systemSettings.serverStatus === 'online' ? 'text-[#2EF2C4] mb-4' : 'text-red-500 mb-4'} size={32}/>
                  <p className="text-white/30 text-[10px] font-black uppercase tracking-widest">Server Status</p>
                  <h3 className="text-2xl font-montserrat font-black text-white uppercase">{systemSettings.serverStatus}</h3>
                </div>
                <div className="bg-[#162031] p-8 rounded-2xl border border-white/5">
                  <ShieldCheck className="text-[#7A3CFF] mb-4" size={32}/>
                  <p className="text-white/30 text-[10px] font-black uppercase tracking-widest">Firewall</p>
                  <h3 className="text-2xl font-montserrat font-black text-white uppercase">Active</h3>
                </div>
              </div>
            </AnimatedSection>
          )}

          {/* GLOBAL CONTROL TAB */}
          {activeTab === 'settings' && userRole === 'owner' && (
            <AnimatedSection className="space-y-6">
              <div className="bg-[#162031] p-8 rounded-2xl border border-white/5">
                <h3 className="text-xl font-montserrat font-black text-white mb-8 uppercase tracking-tight flex items-center gap-3">
                  <Globe className="text-[#2EF2C4]"/> Global Network Control
                </h3>
                
                <div className="space-y-8">
                  {/* Maintenance Switch */}
                  <div className="flex items-center justify-between p-6 bg-[#0E1624] rounded-xl border border-white/5">
                    <div>
                      <h4 className="font-bold text-white mb-1">Maintenance Mode</h4>
                      <p className="text-white/40 text-xs uppercase tracking-widest">Restrict access to all survivors</p>
                    </div>
                    <button 
                      onClick={() => updateGlobalSettings({ maintenance: !systemSettings.maintenance })}
                      className={`w-14 h-8 rounded-full transition-all relative ${systemSettings.maintenance ? 'bg-red-500' : 'bg-white/10'}`}
                    >
                      <div className={`absolute top-1 w-6 h-6 rounded-full bg-white transition-all ${systemSettings.maintenance ? 'left-7' : 'left-1'}`}></div>
                    </button>
                  </div>

                  {/* Inputs */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3">Server Status</label>
                      <select 
                        value={systemSettings.serverStatus} 
                        onChange={(e) => updateGlobalSettings({ serverStatus: e.target.value })}
                        className="w-full bg-[#0E1624] border border-white/10 rounded-xl p-4 text-white outline-none focus:border-[#2EF2C4]"
                      >
                        <option value="online">🟢 Online / Stable</option>
                        <option value="congested">🟡 High Load / Lag</option>
                        <option value="offline">🔴 Offline / Down</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-white/30 uppercase tracking-widest mb-3">Global Announcement</label>
                      <input 
                        type="text" 
                        value={systemSettings.announcement} 
                        onChange={(e) => updateGlobalSettings({ announcement: e.target.value })}
                        placeholder="Type alert message..."
                        className="w-full bg-[#0E1624] border border-white/10 rounded-xl p-4 text-white outline-none focus:border-[#2EF2C4]"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          )}

          {/* --- ÚJ: ITEM DATABASE TAB --- */}
          {activeTab === 'items' && ['owner', 'developer'].includes(userRole) && (
            <AnimatedSection>
              {/* Itt hívjuk be az ItemEditor komponenst */}
              <ItemEditor />
            </AnimatedSection>
          )}

          {/* BUG REPORTS TAB */}
          {activeTab === 'bugs' && (
            <AnimatedSection className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-montserrat font-black text-white uppercase">Neural Anomalies</h3>
                <div className="flex bg-[#162031] rounded-lg p-1 border border-white/5">
                  {['new', 'resolved', 'all'].map(f => (
                    <button key={f} onClick={() => setBugFilter(f)} className={`px-4 py-1.5 rounded-md text-[10px] font-black uppercase transition-all ${bugFilter===f ? 'bg-[#7A3CFF] text-white shadow-lg' : 'text-white/40 hover:text-white'}`}>
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {displayedBugs.length === 0 ? (
                  <div className="p-20 bg-[#162031] rounded-2xl text-center border border-white/5">
                    <CheckCircle className="mx-auto mb-4 text-[#2EF2C4] opacity-20" size={48}/>
                    <p className="text-white/20 font-black uppercase tracking-widest text-xs">No anomalies detected</p>
                  </div>
                ) : (
                  displayedBugs.map(bug => (
                    <div key={bug.id} className={`bg-[#162031] border border-white/5 p-6 rounded-2xl transition-all ${bug.status==='resolved'?'opacity-40':''}`}>
                      <div className="flex flex-col md:flex-row justify-between gap-6">
                        <div className="flex-grow">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="px-2 py-0.5 bg-[#7A3CFF]/20 text-[#7A3CFF] text-[10px] font-black rounded uppercase">{bug.category}</span>
                            <span className="text-[#2EF2C4] text-[10px] font-black uppercase">{bug.subCategory}</span>
                            <span className="ml-auto text-[10px] text-white/20 font-bold">{new Date(bug.timestamp).toLocaleString()}</span>
                          </div>
                          <h4 className="text-white font-bold text-lg mb-1">{bug.title}</h4>
                          <p className="text-white/50 text-sm mb-4">{bug.desc}</p>
                          <p className="text-[10px] text-white/30 font-black uppercase flex items-center gap-2"><User size={12}/> {bug.userName}</p>
                        </div>
                        <div className="flex md:flex-col gap-2 shrink-0">
                          <button onClick={() => updateBugStatus(bug.id, bug.status==='resolved'?'new':'resolved')} className={`px-4 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${bug.status==='resolved'?'bg-[#2EF2C4] text-[#0E1624]':'border border-white/10 text-white hover:bg-white/5'}`}>
                            {bug.status==='resolved'?'Re-open':'Resolve'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </AnimatedSection>
          )}

          {/* PERSONNEL TAB */}
          {activeTab === 'users' && userRole === 'owner' && (
            <AnimatedSection className="bg-[#162031] rounded-2xl border border-white/5 overflow-hidden">
               <div className="p-8 border-b border-white/5">
                 <h3 className="text-xl font-montserrat font-black text-white uppercase">Personnel Database</h3>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full text-left">
                   <thead className="bg-white/5 text-[10px] font-black text-white/30 uppercase tracking-widest">
                     <tr><th className="px-8 py-5">Profile</th><th className="px-8 py-5">Access Level</th><th className="px-8 py-5">Assign</th></tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                     {usersList.map(u => (
                       <tr key={u.uid} className="hover:bg-white/[0.02]">
                         <td className="px-8 py-6 flex items-center gap-4">
                           <img src={u.photoURL} className="w-10 h-10 rounded-full border border-white/10" alt=""/>
                           <div><p className="text-white font-bold">{u.name}</p><p className="text-[10px] text-white/30 font-mono uppercase">{u.uid}</p></div>
                         </td>
                         <td className="px-8 py-6">
                           <span className={`px-3 py-1 rounded text-[10px] font-black uppercase border ${u.role==='owner'?'text-red-400 border-red-400/30' : 'text-white/40 border-white/10'}`}>
                             {u.role || 'default'}
                           </span>
                         </td>
                         <td className="px-8 py-6">
                           {u.role !== 'owner' ? (
                             <select value={u.role || 'default'} onChange={(e)=>updateUserRole(u.uid, e.target.value)} className="bg-[#0E1624] border border-white/10 rounded-lg p-2 text-xs text-white outline-none">
                               <option value="default">Default</option>
                               <option value="moderator">Moderator</option>
                               <option value="developer">Developer</option>
                             </select>
                           ) : <span className="text-[10px] font-black text-red-500 uppercase">Master</span>}
                         </td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </AnimatedSection>
          )}

        </div>
      </div>
    </main>
  );
}